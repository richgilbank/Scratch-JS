chrome.devtools.panels.create(
  'ES6 Repl',
  '30.png',
  'Panel/repl.html',
  function(panel) {
    console.log('here', panel);
  }
);
